from django.contrib import admin
from django.urls import path, include
from studio import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home),  # this connects "/" to your home() function
    path('api/', include('studio.urls')),
]
