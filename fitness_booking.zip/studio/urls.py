from django.urls import path
from . import views

urlpatterns = [
    path('classes/', views.classes_list, name='classes_list'),
    path('book/', views.book_class, name='book_class'),
    path('bookings/', views.bookings_by_email, name='bookings_by_email'),
    path('seed/', views.seed_data, name='seed_data'),
]
