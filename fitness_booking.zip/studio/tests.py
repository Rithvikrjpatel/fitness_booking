from django.test import TestCase, Client
from django.urls import reverse
from .models import FitnessClass
from zoneinfo import ZoneInfo
from django.utils import timezone as dj_tz

class ApiTests(TestCase):
    def setUp(self):
        self.client = Client()
        tz = ZoneInfo('Asia/Kolkata')
        now = dj_tz.now().astimezone(tz).replace(hour=9, minute=0, second=0, microsecond=0)
        FitnessClass.objects.create(name='Yoga', instructor='Asha', start_time=now, capacity=5, available_slots=5)
    def test_get_classes(self):
        resp = self.client.get(reverse('classes_list'))
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(isinstance(data, list))
    def test_booking(self):
        cls = FitnessClass.objects.first()
        resp = self.client.post(reverse('book_class'), content_type='application/json', data='{"class_id": %d, "client_name":"Bob","client_email":"bob@example.com"}'%cls.id)
        self.assertEqual(resp.status_code, 200)
        j = resp.json()
        self.assertTrue(j.get('success', False))
