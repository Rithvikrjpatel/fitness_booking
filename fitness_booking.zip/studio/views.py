import json
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from zoneinfo import ZoneInfo
from .models import FitnessClass, Booking

from django.http import JsonResponse

def home(request):
    return JsonResponse({
        "message": "Welcome to the Fitness Studio Booking API",
        "endpoints": {
            "seed": "/api/seed/",
            "classes": "/api/classes/",
            "book": "POST /api/book/",
            "bookings": "/api/bookings/?email=you@example.com"
        }
    })

def _to_client_tz(dt, tz_name):
    try:
        z = ZoneInfo(tz_name)
    except Exception:
        z = ZoneInfo('Asia/Kolkata')
    return dt.astimezone(z)

def classes_list(request):
    # optional query param tz=Europe/London etc.
    tz = request.GET.get('tz', 'Asia/Kolkata')
    classes = FitnessClass.objects.all().order_by('start_time')
    out = []
    for c in classes:
        start_client = _to_client_tz(c.start_time, tz)
        out.append({
            'id': c.id,
            'name': c.name,
            'instructor': c.instructor,
            'start_time': start_client.isoformat(),
            'duration_minutes': c.duration_minutes,
            'capacity': c.capacity,
            'available_slots': c.available_slots,
        })
    return JsonResponse(out, safe=False)

@csrf_exempt
def book_class(request):
    if request.method != 'POST':
        return HttpResponseBadRequest(json.dumps({'error':'POST required'}), content_type='application/json')
    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return HttpResponseBadRequest(json.dumps({'error':'invalid json'}), content_type='application/json')
    class_id = data.get('class_id')
    name = data.get('client_name')
    email = data.get('client_email')
    if not (class_id and name and email):
        return HttpResponseBadRequest(json.dumps({'error':'missing fields'}), content_type='application/json')
    try:
        fc = FitnessClass.objects.select_for_update().get(id=class_id)
    except FitnessClass.DoesNotExist:
        return HttpResponseBadRequest(json.dumps({'error':'class not found'}), content_type='application/json')
    # Check availability
    if fc.available_slots <= 0:
        return HttpResponseBadRequest(json.dumps({'error':'no slots available'}), content_type='application/json')
    # reduce slot and create booking
    fc.available_slots -= 1
    fc.save()
    booking = Booking.objects.create(fitness_class=fc, client_name=name, client_email=email)
    return JsonResponse({
        'success': True,
        'booking_id': booking.id,
        'class_id': fc.id,
        'client_name': booking.client_name,
        'client_email': booking.client_email,
    })

def bookings_by_email(request):
    email = request.GET.get('email')
    if not email:
        return HttpResponseBadRequest(json.dumps({'error':'provide email as query param'}), content_type='application/json')
    bookings = Booking.objects.filter(client_email__iexact=email).select_related('fitness_class').order_by('-booked_at')
    out = []
    for b in bookings:
        out.append({
            'booking_id': b.id,
            'client_name': b.client_name,
            'client_email': b.client_email,
            'booked_at': b.booked_at.isoformat(),
            'class': {
                'id': b.fitness_class.id,
                'name': b.fitness_class.name,
                'start_time': b.fitness_class.start_time.isoformat(),
                'instructor': b.fitness_class.instructor,
            }
        })
    return JsonResponse(out, safe=False)

def seed_data(request):
    # creates sample classes in IST timezone (Asia/Kolkata)
    from django.utils import timezone as dj_tz
    import datetime
    ist = ZoneInfo('Asia/Kolkata')
    # remove existing
    FitnessClass.objects.all().delete()
    Booking.objects.all().delete()
    now = dj_tz.now().astimezone(ist)
    # create three classes
    times = [
        now.replace(hour=9, minute=0, second=0, microsecond=0),
        now.replace(hour=12, minute=0, second=0, microsecond=0),
        now.replace(hour=18, minute=30, second=0, microsecond=0),
    ]
    for i, t in enumerate(times, start=1):
        # ensure tzinfo is set
        if t.tzinfo is None:
            t = t.replace(tzinfo=ist)
        FitnessClass.objects.create(
            name=['Yoga','Zumba','HIIT'][i-1],
            instructor=['Asha','Ravi','Maya'][i-1],
            start_time=t.astimezone(ZoneInfo('Asia/Kolkata')),
            duration_minutes=60,
            capacity=10,
            available_slots=10,
        )
    return JsonResponse({'seeded': True})
