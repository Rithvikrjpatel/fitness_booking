# Generated manual initial migration for studio app
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone

class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='FitnessClass',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('instructor', models.CharField(max_length=100)),
                ('start_time', models.DateTimeField(help_text='Stored as timezone-aware datetime (IST by default)')),
                ('duration_minutes', models.IntegerField(default=60)),
                ('capacity', models.IntegerField(default=10)),
                ('available_slots', models.IntegerField(default=10)),
            ],
        ),
        migrations.CreateModel(
            name='Booking',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('client_name', models.CharField(max_length=200)),
                ('client_email', models.EmailField(max_length=254)),
                ('booked_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('fitness_class', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='bookings', to='studio.fitnessclass')),
            ],
        ),
    ]
