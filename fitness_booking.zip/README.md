# Fitness Studio Booking API (Django)
## Quick overview
A minimal Django app implementing a small Booking API for a fitness studio.
**Endpoints**
- `GET /api/classes/?tz=<TZ>` - list classes. Optional `tz` query param (e.g., Europe/London) to convert class times to that timezone.
- `POST /api/book/` - create a booking. JSON body: `{ "class_id": <id>, "client_name": "Name", "client_email": "email" }`
- `GET /api/bookings/?email=<email>` - list bookings for an email.
- `GET /api/seed/` - create sample seed data (for testing/demo).

## Features
- Classes are created/seeded in **Asia/Kolkata** (IST).
- When clients request classes, you can pass a timezone to convert displayed times to the client's timezone.
- Basic validation and overbooking prevention (simple check).
- Includes a tiny test suite.

## Setup (VS Code / local)
1. Ensure Python 3.9+ is installed.
2. Unzip the project and open the folder in VS Code.
3. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   # windows
   venv\Scripts\activate
   # mac / linux
   source venv/bin/activate
   ```
4. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
5. Run migrations and seed sample data:
   ```bash
   python manage.py migrate
   python manage.py loaddata # not required; instead use seed endpoint
   python manage.py runserver
   # or seed using the endpoint:
   # curl http://127.0.0.1:8000/api/seed/
   ```
6. Use the API:
   - Get classes (converted to UTC): `curl 'http://127.0.0.1:8000/api/classes/?tz=UTC'`
   - Book a class:
     ```bash
     curl -X POST http://127.0.0.1:8000/api/book/ -H 'Content-Type: application/json' -d '{"class_id":1, "client_name":"Jon", "client_email":"jon@example.com"}'
     ```
   - Get bookings for an email:
     ```bash
     curl 'http://127.0.0.1:8000/api/bookings/?email=jon@example.com'
     ```

## Notes on timezone handling
- Classes are created in IST. When the client provides a `tz` query parameter (IANA timezone name like `Europe/London` or `America/New_York`), the API converts class times to that timezone in the response.
- If an invalid timezone is passed, the server falls back to Asia/Kolkata.

## Tests
```bash
python manage.py test
```

## Deliverables
This folder contains the Django project. You can zip it and upload to GitHub. For a Loom walkthrough, record your local setup and usage (seed, list classes, book, show DB admin if desired).


# Fixes applied
- booking_project/urls.py updated to use 'studio' app
- Added initial migration for studio app so tables exist after `migrate`.

Run `python manage.py migrate` before using the seed endpoint.
